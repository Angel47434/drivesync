# Drive Sync Sprint 1

Sprint 1 foundation for Drive Sync: multi-tenant SaaS authentication, school registration, user roles, feature flags, audit logs, and basic frontend screens.

## Stack
- Backend: FastAPI, SQLAlchemy, PostgreSQL, JWT
- Frontend: React, TypeScript, Axios, React Router
- Database: PostgreSQL

## Sprint 1 Scope
- School registration
- Login/authentication
- Role-based access
- Tenant isolation by school_id
- Feature flags
- Founder dashboard
- School settings
- User management scaffold

Future modules are intentionally not included yet:
- Scheduling
- Payments
- Trainees
- Instructors
- Equipment
- Documents
- AI
