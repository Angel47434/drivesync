from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database.database import Base, engine
from app.api import auth, schools, users, feature_flags, founder

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Drive Sync API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/auth", tags=["Authentication"])
app.include_router(schools.router, prefix="/schools", tags=["Schools"])
app.include_router(users.router, prefix="/users", tags=["Users"])
app.include_router(feature_flags.router, prefix="/feature-flags", tags=["Feature Flags"])
app.include_router(founder.router, prefix="/founder", tags=["Founder Dashboard"])

@app.get("/")
def root():
    return {"message": "Drive Sync API Running"}
