from pydantic import BaseModel, EmailStr

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"

class RegisterSchoolRequest(BaseModel):
    school_name: str
    school_type: str | None = None
    owner_first_name: str
    owner_last_name: str
    email: EmailStr
    phone: str | None = None
    website: str | None = None
    address: str | None = None
    city: str | None = None
    state: str | None = None
    zip_code: str | None = None
    password: str
