from pydantic import BaseModel, EmailStr

class SchoolOut(BaseModel):
    id: int
    school_name: str
    school_type: str | None = None
    email: EmailStr
    phone: str | None = None
    status: str
    subscription_plan: str
    billing_status: str

    class Config:
        from_attributes = True

class SchoolUpdate(BaseModel):
    school_name: str | None = None
    phone: str | None = None
    website: str | None = None
    address: str | None = None
    city: str | None = None
    state: str | None = None
    zip_code: str | None = None
    primary_color: str | None = None
