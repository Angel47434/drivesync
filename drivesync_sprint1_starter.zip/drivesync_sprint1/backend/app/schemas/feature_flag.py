from pydantic import BaseModel

class FeatureFlagOut(BaseModel):
    id: int
    school_id: int
    feature_key: str
    feature_name: str
    is_enabled: bool

    class Config:
        from_attributes = True
