from pydantic import BaseModel, EmailStr

class UserCreate(BaseModel):
    first_name: str
    last_name: str
    email: EmailStr
    phone: str | None = None
    password: str
    role: str

class UserOut(BaseModel):
    id: int
    school_id: int | None = None
    first_name: str | None = None
    last_name: str | None = None
    email: EmailStr
    phone: str | None = None
    role: str
    status: str

    class Config:
        from_attributes = True
