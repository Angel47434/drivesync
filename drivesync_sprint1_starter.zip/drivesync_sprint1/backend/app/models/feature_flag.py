from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, UniqueConstraint
from app.database.database import Base

class FeatureFlag(Base):
    __tablename__ = "feature_flags"

    id = Column(Integer, primary_key=True, index=True)
    school_id = Column(Integer, ForeignKey("schools.id"), nullable=False)
    feature_key = Column(String(100), nullable=False)
    feature_name = Column(String(255), nullable=False)
    is_enabled = Column(Boolean, default=False)
    enabled_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    enabled_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (UniqueConstraint("school_id", "feature_key", name="uq_school_feature"),)
