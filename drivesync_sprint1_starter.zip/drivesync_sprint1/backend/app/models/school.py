from datetime import datetime, date, timedelta
from sqlalchemy import Column, Integer, String, Text, DateTime, Date
from app.database.database import Base

class School(Base):
    __tablename__ = "schools"

    id = Column(Integer, primary_key=True, index=True)
    school_name = Column(String(255), nullable=False)
    school_type = Column(String(100))
    owner_name = Column(String(255))
    email = Column(String(255), unique=True, nullable=False)
    phone = Column(String(50))
    website = Column(String(255))
    address = Column(Text)
    city = Column(String(100))
    state = Column(String(50))
    zip_code = Column(String(20))
    logo_url = Column(Text)
    primary_color = Column(String(20), default="#2563EB")
    subscription_plan = Column(String(50), default="starter")
    billing_status = Column(String(50), default="trial")
    status = Column(String(50), default="active")
    trial_start_date = Column(Date, default=date.today)
    trial_end_date = Column(Date, default=lambda: date.today() + timedelta(days=14))
    created_at = Column(DateTime, default=datetime.utcnow)
