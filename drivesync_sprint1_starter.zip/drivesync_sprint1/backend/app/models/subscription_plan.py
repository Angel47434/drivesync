from datetime import datetime
from sqlalchemy import Column, Integer, String, Numeric, Boolean, DateTime
from app.database.database import Base

class SubscriptionPlan(Base):
    __tablename__ = "subscription_plans"

    id = Column(Integer, primary_key=True, index=True)
    plan_name = Column(String(100), nullable=False)
    monthly_price = Column(Numeric(10, 2))
    annual_price = Column(Numeric(10, 2))
    max_users = Column(Integer)
    max_trainees = Column(Integer)
    instantbook_enabled = Column(Boolean, default=False)
    ai_enabled = Column(Boolean, default=False)
    white_label_enabled = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
