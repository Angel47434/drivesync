from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database.database import get_db
from app.models.user import User
from app.schemas.user import UserCreate, UserOut
from app.auth.password import hash_password
from app.core.dependencies import get_current_user, require_roles
from app.services.audit_service import create_audit_log

router = APIRouter()

@router.get("", response_model=list[UserOut])
def list_users(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("SUPER_ADMIN", "SCHOOL_OWNER", "SCHOOL_ADMIN")),
):
    query = db.query(User)
    if current_user.role != "SUPER_ADMIN":
        query = query.filter(User.school_id == current_user.school_id)
    return query.all()

@router.post("", response_model=UserOut)
def create_user(
    payload: UserCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("SUPER_ADMIN", "SCHOOL_OWNER", "SCHOOL_ADMIN")),
):
    existing = db.query(User).filter(User.email == payload.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already exists")

    school_id = current_user.school_id
    if current_user.role == "SUPER_ADMIN":
        school_id = current_user.school_id

    user = User(
        school_id=school_id,
        first_name=payload.first_name,
        last_name=payload.last_name,
        email=payload.email,
        phone=payload.phone,
        password_hash=hash_password(payload.password),
        role=payload.role,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    create_audit_log(db, user.school_id, current_user.id, "CREATE_USER", "user", user.id, f"Created user {user.email}")
    return user

@router.delete("/{user_id}")
def disable_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("SUPER_ADMIN", "SCHOOL_OWNER", "SCHOOL_ADMIN")),
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    if current_user.role != "SUPER_ADMIN" and user.school_id != current_user.school_id:
        raise HTTPException(status_code=403, detail="Cannot disable another school's user")

    user.status = "inactive"
    db.commit()
    create_audit_log(db, user.school_id, current_user.id, "DISABLE_USER", "user", user.id, f"Disabled user {user.email}")
    return {"message": "User disabled"}
