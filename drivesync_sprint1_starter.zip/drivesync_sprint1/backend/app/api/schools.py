from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database.database import get_db
from app.models.school import School
from app.models.user import User
from app.schemas.school import SchoolOut, SchoolUpdate
from app.core.dependencies import get_current_user, require_roles
from app.services.audit_service import create_audit_log

router = APIRouter()

@router.get("", response_model=list[SchoolOut])
def list_schools(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("SUPER_ADMIN")),
):
    return db.query(School).all()

@router.get("/{school_id}", response_model=SchoolOut)
def get_school(school_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if current_user.role != "SUPER_ADMIN" and current_user.school_id != school_id:
        raise HTTPException(status_code=403, detail="Cannot access another school")

    school = db.query(School).filter(School.id == school_id).first()
    if not school:
        raise HTTPException(status_code=404, detail="School not found")
    return school

@router.put("/{school_id}", response_model=SchoolOut)
def update_school(
    school_id: int,
    payload: SchoolUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("SUPER_ADMIN", "SCHOOL_OWNER", "SCHOOL_ADMIN")),
):
    if current_user.role != "SUPER_ADMIN" and current_user.school_id != school_id:
        raise HTTPException(status_code=403, detail="Cannot update another school")

    school = db.query(School).filter(School.id == school_id).first()
    if not school:
        raise HTTPException(status_code=404, detail="School not found")

    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(school, key, value)

    db.commit()
    db.refresh(school)
    create_audit_log(db, school.id, current_user.id, "UPDATE_SCHOOL", "school", school.id, "School settings updated")
    return school
