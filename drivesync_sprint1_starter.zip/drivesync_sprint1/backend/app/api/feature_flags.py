from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database.database import get_db
from app.models.user import User
from app.models.feature_flag import FeatureFlag
from app.schemas.feature_flag import FeatureFlagOut
from app.core.dependencies import require_roles
from app.services.audit_service import create_audit_log

router = APIRouter()

@router.get("", response_model=list[FeatureFlagOut])
def list_feature_flags(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("SUPER_ADMIN", "SCHOOL_OWNER", "SCHOOL_ADMIN")),
):
    query = db.query(FeatureFlag)
    if current_user.role != "SUPER_ADMIN":
        query = query.filter(FeatureFlag.school_id == current_user.school_id)
    return query.all()

@router.post("/{flag_id}/enable", response_model=FeatureFlagOut)
def enable_feature_flag(
    flag_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("SUPER_ADMIN", "SCHOOL_OWNER")),
):
    flag = db.query(FeatureFlag).filter(FeatureFlag.id == flag_id).first()
    if not flag:
        raise HTTPException(status_code=404, detail="Feature flag not found")

    if current_user.role != "SUPER_ADMIN" and flag.school_id != current_user.school_id:
        raise HTTPException(status_code=403, detail="Cannot modify another school's feature flags")

    flag.is_enabled = True
    flag.enabled_by = current_user.id
    flag.enabled_at = datetime.utcnow()
    db.commit()
    db.refresh(flag)
    create_audit_log(db, flag.school_id, current_user.id, "ENABLE_FEATURE", "feature_flag", flag.id, flag.feature_key)
    return flag

@router.post("/{flag_id}/disable", response_model=FeatureFlagOut)
def disable_feature_flag(
    flag_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("SUPER_ADMIN", "SCHOOL_OWNER")),
):
    flag = db.query(FeatureFlag).filter(FeatureFlag.id == flag_id).first()
    if not flag:
        raise HTTPException(status_code=404, detail="Feature flag not found")

    if current_user.role != "SUPER_ADMIN" and flag.school_id != current_user.school_id:
        raise HTTPException(status_code=403, detail="Cannot modify another school's feature flags")

    flag.is_enabled = False
    db.commit()
    db.refresh(flag)
    create_audit_log(db, flag.school_id, current_user.id, "DISABLE_FEATURE", "feature_flag", flag.id, flag.feature_key)
    return flag
