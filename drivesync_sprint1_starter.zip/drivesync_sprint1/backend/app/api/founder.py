from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.database.database import get_db
from app.models.school import School
from app.models.user import User
from app.models.feature_flag import FeatureFlag
from app.core.dependencies import require_roles

router = APIRouter()

@router.get("/dashboard")
def founder_dashboard(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("SUPER_ADMIN")),
):
    active_schools = db.query(School).filter(School.status == "active").count()
    trial_schools = db.query(School).filter(School.billing_status == "trial").count()
    suspended_schools = db.query(School).filter(School.status == "suspended").count()
    total_users = db.query(User).count()

    feature_rows = (
        db.query(FeatureFlag.feature_key, func.count(FeatureFlag.id))
        .filter(FeatureFlag.is_enabled == True)
        .group_by(FeatureFlag.feature_key)
        .all()
    )

    return {
        "active_schools": active_schools,
        "trial_schools": trial_schools,
        "suspended_schools": suspended_schools,
        "total_users": total_users,
        "feature_adoption": {key: count for key, count in feature_rows},
    }
