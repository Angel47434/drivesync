from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database.database import get_db
from app.models.school import School
from app.models.user import User
from app.schemas.auth import LoginRequest, TokenResponse, RegisterSchoolRequest
from app.auth.password import hash_password, verify_password
from app.auth.jwt_handler import create_access_token
from app.core.dependencies import get_current_user
from app.services.feature_flag_service import create_default_feature_flags
from app.services.audit_service import create_audit_log
from app.models.feature_flag import FeatureFlag

router = APIRouter()

@router.post("/register-school", response_model=TokenResponse)
def register_school(payload: RegisterSchoolRequest, db: Session = Depends(get_db)):
    existing_school = db.query(School).filter(School.email == payload.email).first()
    existing_user = db.query(User).filter(User.email == payload.email).first()
    if existing_school or existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")

    school = School(
        school_name=payload.school_name,
        school_type=payload.school_type,
        owner_name=f"{payload.owner_first_name} {payload.owner_last_name}",
        email=payload.email,
        phone=payload.phone,
        website=payload.website,
        address=payload.address,
        city=payload.city,
        state=payload.state,
        zip_code=payload.zip_code,
    )
    db.add(school)
    db.commit()
    db.refresh(school)

    owner = User(
        school_id=school.id,
        first_name=payload.owner_first_name,
        last_name=payload.owner_last_name,
        email=payload.email,
        phone=payload.phone,
        password_hash=hash_password(payload.password),
        role="SCHOOL_OWNER",
    )
    db.add(owner)
    db.commit()
    db.refresh(owner)

    create_default_feature_flags(db, school.id)
    create_audit_log(db, school.id, owner.id, "REGISTER_SCHOOL", "school", school.id, "School registered")

    token = create_access_token({"sub": str(owner.id), "role": owner.role, "school_id": owner.school_id})
    return TokenResponse(access_token=token)

@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == payload.email).first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    if user.status != "active":
        raise HTTPException(status_code=403, detail="User account is inactive")

    user.last_login = datetime.utcnow()
    db.commit()

    token = create_access_token({"sub": str(user.id), "role": user.role, "school_id": user.school_id})
    return TokenResponse(access_token=token)

@router.get("/me")
def me(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    features = {}
    if current_user.school_id:
        flags = db.query(FeatureFlag).filter(FeatureFlag.school_id == current_user.school_id).all()
        features = {flag.feature_key: flag.is_enabled for flag in flags}

    return {
        "id": current_user.id,
        "school_id": current_user.school_id,
        "first_name": current_user.first_name,
        "last_name": current_user.last_name,
        "email": current_user.email,
        "role": current_user.role,
        "features": features,
    }
