from sqlalchemy.orm import Session
from app.models.audit_log import AuditLog

def create_audit_log(db: Session, school_id: int | None, user_id: int | None, action: str, entity_type: str | None = None, entity_id: int | None = None, details: str | None = None):
    log = AuditLog(
        school_id=school_id,
        user_id=user_id,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        details=details,
    )
    db.add(log)
    db.commit()
    return log
