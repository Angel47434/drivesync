from sqlalchemy.orm import Session
from app.models.feature_flag import FeatureFlag

DEFAULT_FEATURE_FLAGS = [
    ("instantbook", "InstantBook™"),
    ("pay_later", "Pay Later™"),
    ("smartmatch", "SmartMatch™"),
    ("waitlist_intelligence", "Waitlist Intelligence™"),
    ("student_readiness_score", "Student Readiness Score™"),
    ("ai_coaching", "AI Coaching Module™"),
    ("smart_lesson_builder", "Smart Lesson Builder™"),
    ("pass_probability", "Pass Probability Analysis™"),
    ("capacity_planner", "Smart Capacity Planner™"),
    ("white_label", "White Label"),
    ("sms_messaging", "SMS Messaging"),
    ("quickbooks_sync", "QuickBooks Sync"),
    ("fleet_module", "Fleet Module"),
    ("cdl_module", "CDL Module"),
    ("motorcycle_module", "Motorcycle Module"),
    ("evoc_module", "EVOC Module"),
]

def create_default_feature_flags(db: Session, school_id: int):
    flags = []
    for key, name in DEFAULT_FEATURE_FLAGS:
        flag = FeatureFlag(
            school_id=school_id,
            feature_key=key,
            feature_name=name,
            is_enabled=False,
        )
        db.add(flag)
        flags.append(flag)
    db.commit()
    return flags
