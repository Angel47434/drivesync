import React from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login";
import RegisterSchool from "./pages/RegisterSchool";
import FounderDashboard from "./pages/FounderDashboard";
import SchoolSettings from "./pages/SchoolSettings";
import UserManagement from "./pages/UserManagement";
import DashboardLayout from "./layouts/DashboardLayout";
import "./styles.css";

function App() {
  const token = localStorage.getItem("token");

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register-school" element={<RegisterSchool />} />
        <Route
          path="/"
          element={token ? <DashboardLayout /> : <Navigate to="/login" />}
        >
          <Route index element={<FounderDashboard />} />
          <Route path="settings" element={<SchoolSettings />} />
          <Route path="users" element={<UserManagement />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

createRoot(document.getElementById("root")!).render(<App />);
