import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../services/api";

export default function RegisterSchool() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    school_name: "",
    school_type: "Driving School",
    owner_first_name: "",
    owner_last_name: "",
    email: "",
    phone: "",
    website: "",
    address: "",
    city: "",
    state: "",
    zip_code: "",
    password: "",
  });

  function update(field: string, value: string) {
    setForm({ ...form, [field]: value });
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const response = await api.post("/auth/register-school", form);
    localStorage.setItem("token", response.data.access_token);
    navigate("/");
  }

  return (
    <div className="auth-page">
      <form className="auth-card wide" onSubmit={submit}>
        <h1>Create Drive Sync Account</h1>
        {Object.entries(form).map(([key, value]) => (
          <input
            key={key}
            type={key === "password" ? "password" : "text"}
            placeholder={key.replaceAll("_", " ")}
            value={value}
            onChange={(e) => update(key, e.target.value)}
          />
        ))}
        <button type="submit">Register School</button>
      </form>
    </div>
  );
}
