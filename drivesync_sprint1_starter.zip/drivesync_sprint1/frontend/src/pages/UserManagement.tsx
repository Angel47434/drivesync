import React, { useEffect, useState } from "react";
import { api } from "../services/api";

export default function UserManagement() {
  const [users, setUsers] = useState<any[]>([]);

  async function load() {
    const response = await api.get("/users");
    setUsers(response.data);
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <>
      <h1>User Management</h1>
      <div className="card">
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id}>
                <td>{u.first_name} {u.last_name}</td>
                <td>{u.email}</td>
                <td>{u.role}</td>
                <td>{u.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
