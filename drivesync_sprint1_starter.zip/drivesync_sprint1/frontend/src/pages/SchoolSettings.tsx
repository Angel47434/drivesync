import React, { useEffect, useState } from "react";
import { api } from "../services/api";

export default function SchoolSettings() {
  const [me, setMe] = useState<any>(null);
  const [school, setSchool] = useState<any>(null);
  const [flags, setFlags] = useState<any[]>([]);

  useEffect(() => {
    api.get("/auth/me").then((res) => {
      setMe(res.data);
      if (res.data.school_id) {
        api.get(`/schools/${res.data.school_id}`).then((schoolRes) => setSchool(schoolRes.data));
      }
    });
    api.get("/feature-flags").then((res) => setFlags(res.data)).catch(() => setFlags([]));
  }, []);

  async function toggleFlag(flag: any) {
    const action = flag.is_enabled ? "disable" : "enable";
    await api.post(`/feature-flags/${flag.id}/${action}`);
    const res = await api.get("/feature-flags");
    setFlags(res.data);
  }

  return (
    <>
      <h1>School Settings</h1>
      <div className="card">
        <h3>{school?.school_name ?? "School"}</h3>
        <p>{school?.email}</p>
        <p>Plan: {school?.subscription_plan}</p>
        <p>Billing: {school?.billing_status}</p>
      </div>

      <div className="card">
        <h3>Feature Flags</h3>
        {flags.map((flag) => (
          <div className="row" key={flag.id}>
            <span>{flag.feature_name}</span>
            <button onClick={() => toggleFlag(flag)}>
              {flag.is_enabled ? "Enabled" : "Disabled"}
            </button>
          </div>
        ))}
      </div>
    </>
  );
}
