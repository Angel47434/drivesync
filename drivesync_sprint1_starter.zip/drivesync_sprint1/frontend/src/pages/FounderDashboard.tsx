import React, { useEffect, useState } from "react";
import { api } from "../services/api";

export default function FounderDashboard() {
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    api.get("/founder/dashboard")
      .then((res) => setData(res.data))
      .catch(() => setData(null));
  }, []);

  return (
    <>
      <h1>Founder Dashboard</h1>
      <div className="grid">
        <div className="card"><h3>Active Schools</h3><strong>{data?.active_schools ?? "-"}</strong></div>
        <div className="card"><h3>Trial Schools</h3><strong>{data?.trial_schools ?? "-"}</strong></div>
        <div className="card"><h3>Suspended Schools</h3><strong>{data?.suspended_schools ?? "-"}</strong></div>
        <div className="card"><h3>Total Users</h3><strong>{data?.total_users ?? "-"}</strong></div>
      </div>
      <div className="card">
        <h3>Feature Adoption</h3>
        <pre>{JSON.stringify(data?.feature_adoption ?? {}, null, 2)}</pre>
      </div>
    </>
  );
}
