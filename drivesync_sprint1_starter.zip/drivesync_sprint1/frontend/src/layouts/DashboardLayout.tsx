import React from "react";
import { Link, Outlet, useNavigate } from "react-router-dom";

export default function DashboardLayout() {
  const navigate = useNavigate();

  function logout() {
    localStorage.removeItem("token");
    navigate("/login");
  }

  return (
    <div className="layout">
      <aside className="sidebar">
        <h2>Drive Sync</h2>
        <Link to="/">Dashboard</Link>
        <Link to="/users">Users</Link>
        <Link to="/settings">Settings</Link>
        <span className="disabled">Calendar</span>
        <span className="disabled">Trainees</span>
        <span className="disabled">Payments</span>
        <span className="disabled">AI Center</span>
      </aside>
      <main>
        <header className="topbar">
          <strong>Drive Sync Admin</strong>
          <button onClick={logout}>Logout</button>
        </header>
        <section className="content">
          <Outlet />
        </section>
      </main>
    </div>
  );
}
